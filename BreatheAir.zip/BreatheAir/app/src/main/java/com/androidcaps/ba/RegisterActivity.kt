package com.androidcaps.ba

import android.content.ContentValues.TAG
import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.util.Log
import android.widget.Toast
import com.androidcaps.ba.databinding.ActivityRegisterBinding
import retrofit2.Call
import retrofit2.Response

class RegisterActivity : BaseActivity() {

    private lateinit var binding: ActivityRegisterBinding
    private val retrofitClient = RetrofitClass()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // login button
        binding.tvLogin.setOnClickListener {
            finish()
        }

        // back button
        binding.btnBack.setOnClickListener {
            finish()
        }

        // register button
        binding.btnSignUp.setOnClickListener {
            register()
        }
    }

    // Memvalidasi Edit Text tidak kosong
    private fun validateUserDetails(): Boolean{
        return when{
            TextUtils.isEmpty(binding.etName.text.toString().trim { it <= ' ' }) ->{
                showErrorSnackBar(getString(R.string.error_msg_enter_name), true)
                false
            }
            TextUtils.isEmpty(binding.etEmail.text.toString().trim { it <= ' ' }) ->{
                showErrorSnackBar(getString(R.string.error_msg_enter_email), true)
                false
            }
            TextUtils.isEmpty(binding.etPhone.text.toString().trim { it <= ' ' }) ->{
                showErrorSnackBar(getString(R.string.error_msg_enter_telepon_number), true)
                false
            }
            TextUtils.isEmpty(binding.etPassword.text.toString().trim { it <= ' ' }) ->{
                showErrorSnackBar(getString(R.string.error_msg_enter_password), true)
                false
            }
            TextUtils.isEmpty(binding.etConfirmPassword.text.toString().trim { it <= ' ' }) ->{
                showErrorSnackBar(getString(R.string.error_msg_enter_confirm_password), true)
                false
            }
            binding.etPassword.text.toString().trim { it <= ' ' } != binding.etConfirmPassword.text.toString().trim { it <= ' ' } ->{
                showErrorSnackBar(getString(R.string.error_msg_passwords_do_not_match), true)
                false
            }
            else -> {
                true
            }
        }
    }

    // register user
    private fun register(){
        // memvalidasi input user
        if(validateUserDetails()){
            showProgressDialog(getString(R.string.please_wait))

            val email : String = binding.etEmail.text.toString().trim { it <= ' ' }
            val password : String = binding.etPassword.text.toString().trim { it <= ' ' }
            val name : String = binding.etName.text.toString().trim { it <= ' ' }
            val phone : String = binding.etPhone.text.toString().trim { it <= ' ' }
            val address: String = binding.etAddress.text.toString().trim { it <= ' ' }

            retrofitClient.apiService.registerUser(RegisterCredentials(email = email, password = password, nama= name, telepon = phone, alamat = address))
                .enqueue(object: retrofit2.Callback<UserResponse>{
                    override fun onResponse(
                        call: Call<UserResponse>,
                        response: Response<UserResponse>
                    ) {
                        hideProgressDialog()
                        if(response.isSuccessful){
                            val userResponse = response.body()!!
                            Log.d(TAG, userResponse.toString())

                            Toast.makeText(this@RegisterActivity, getString(R.string.registration_successful), Toast.LENGTH_SHORT).show()
                            startActivity(Intent(this@RegisterActivity, LoginActivity::class.java))
                            finish()
                        }
                    }

                    override fun onFailure(call: Call<UserResponse>, t: Throwable) {
                        hideProgressDialog()
                        Log.d("responseFailure", t.message.toString())
                        Toast.makeText(this@RegisterActivity, t.message.toString(), Toast.LENGTH_LONG).show()
                    }

                })
        }
    }


}