package com.androidcaps.ba

object Constants {

    const val APP_PREFS = "BreatheAirPrefs"
    const val BASE_URL = "https://main-api-dot-astute-acolyte-381310.et.r.appspot.com/"
    const val REQUEST_LOCATION_CODE = 10
}