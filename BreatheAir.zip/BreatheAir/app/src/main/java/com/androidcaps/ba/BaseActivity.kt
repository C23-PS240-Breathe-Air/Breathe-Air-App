package com.androidcaps.ba

import android.app.Dialog
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.widget.TextView
import com.google.android.material.snackbar.Snackbar

open class BaseActivity : AppCompatActivity() {

    private lateinit var myProgressDialog: Dialog

    fun showErrorSnackBar(message: String, errorMessage: Boolean){
        val snackBar = Snackbar.make(findViewById(android.R.id.content), message, Snackbar.LENGTH_LONG)
        val snackBarView = snackBar.view

        if(errorMessage){
            snackBarView.setBackgroundColor(Color.RED)
        }else{
            snackBarView.setBackgroundColor(Color.GREEN)
        }
        snackBar.show()
    }

    fun showProgressDialog(text: String) {
        myProgressDialog = Dialog(this)
        myProgressDialog.setContentView(R.layout.progress_dialog)
        myProgressDialog.findViewById<TextView>(R.id.tv_progress_text).text = text
        myProgressDialog.setCancelable(false)
        myProgressDialog.setCanceledOnTouchOutside(false)
        myProgressDialog.show()
    }

    fun hideProgressDialog() {
        myProgressDialog.dismiss()
    }
}