package com.androidcaps.ba

data class ApiResponse(
    val status: String,
    val data: ApiData,
    val input_data: List<List<Int>>
)

data class ApiData(
    val desc: Description,
    val airpolution: AirPollution,
    val predicted: List<Any>
)

data class Description(
    val real_lat: Double,
    val real_long: Double,
    val date: String,
    val url: String
)

data class AirPollution(
    val pm25: Int,
    val dew: Number,
    val t: Number,
    val p: Number,
    val w: Double
)