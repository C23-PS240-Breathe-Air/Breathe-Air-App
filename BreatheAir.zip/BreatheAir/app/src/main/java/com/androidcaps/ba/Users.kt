package com.androidcaps.ba

data class Users(
    val id: Int,
    val email: String,
    val password: String,
    val nama: String,
    val alamat: String,
    val telepon: String,
    val img_profile: String
)

data class UserResponse(
    val message: String,
    val token: String,
    val data: Users
)

data class LoginCredentials(
    val email: String,
    val password: String
)

data class RegisterCredentials(
    val email: String,
    val password: String,
    val nama: String,
    val alamat: String,
    val telepon: String
)