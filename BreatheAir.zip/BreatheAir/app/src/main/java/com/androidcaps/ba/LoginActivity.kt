package com.androidcaps.ba

import android.content.ContentValues.TAG
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.text.TextUtils
import android.util.Log
import android.widget.Toast
import com.androidcaps.ba.databinding.ActivityLoginBinding
import retrofit2.Call
import retrofit2.Response

class LoginActivity : BaseActivity() {

    private lateinit var binding: ActivityLoginBinding
    private val retrofitClient = RetrofitClass()
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sharedPreferences = getSharedPreferences(Constants.APP_PREFS, Context.MODE_PRIVATE)

        //memeriksa apakah user sudah masuk
        if(isLoggedIn()){
            //pengguna sudah masuk , dimulai main activity
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }

        // login button
        binding.btnLogin.setOnClickListener {
            login()
        }

        // sign up button
        binding.tvSignUp.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }
    }


    // memvalidasi input login oleh user
    private fun validateLoginDetails(): Boolean{
        return when{
            TextUtils.isEmpty(binding.etEmail.text.toString().trim { it <= ' ' }) ->{
                showErrorSnackBar(getString(R.string.error_msg_enter_email), true)
                false
            }
            TextUtils.isEmpty(binding.etPassword.text.toString().trim { it <= ' ' }) ->{
                showErrorSnackBar(getString(R.string.error_msg_enter_password), true)
                false
            }else ->{
                true
            }
        }
    }

    private fun login() {
        if (validateLoginDetails()) {
            showProgressDialog(getString(R.string.please_wait))

            val email = binding.etEmail.text.toString().trim { it <= ' ' }
            val password = binding.etPassword.text.toString().trim { it <= ' ' }

            retrofitClient.apiService.loginUser(LoginCredentials(email, password))
                .enqueue(object : retrofit2.Callback<UserResponse> {
                    override fun onResponse(call: Call<UserResponse>, response: Response<UserResponse>) {
                        hideProgressDialog()
                        if (response.isSuccessful) {
                            val userResponse = response.body()!!
                            Log.d(TAG, "loggedInUser: $userResponse")
                            Toast.makeText(this@LoginActivity, getString(R.string.login_successful), Toast.LENGTH_SHORT).show()

                            // menyimpan informasi user ke SharedPreferences
                            saveLoggedInUser(userResponse)

                            startActivity(Intent(this@LoginActivity, MainActivity::class.java))
                            finish()
                        }
                    }

                    override fun onFailure(call: Call<UserResponse>, t: Throwable) {
                        hideProgressDialog()
                        Log.d("responseFailure", t.message.toString())
                        Toast.makeText(this@LoginActivity, t.message.toString(), Toast.LENGTH_LONG).show()
                    }

                })
        }
    }

    // menyimpan pengguna masuk ke Shared Preferences
    private fun saveLoggedInUser(userResponse: UserResponse) {
        val editor = sharedPreferences.edit()
        editor.putString("email", userResponse.data.email)
        editor.putString("token", userResponse.token)
        editor.apply()
    }

    private fun isLoggedIn(): Boolean {
        val email = sharedPreferences.getString("email", null)
        val token = sharedPreferences.getString("token", null)
        // check if email and token are not null, indicating a logged-in user
        return email != null && token != null
    }

}