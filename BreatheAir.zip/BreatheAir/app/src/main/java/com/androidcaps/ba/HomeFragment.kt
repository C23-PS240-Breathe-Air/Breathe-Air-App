package com.androidcaps.ba

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import com.androidcaps.ba.databinding.FragmentHomeBinding
import retrofit2.Call
import retrofit2.Response

class HomeFragment : Fragment() {

    private lateinit var binding: FragmentHomeBinding
    private val retrofitClient = RetrofitClass()
    private lateinit var myProgressDialog: Dialog

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentHomeBinding.inflate(inflater, container, false)
        val view = binding.root

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // mendapatkan nama alamat saat ini dari shared preferences
        val sharedPrefs = requireContext().getSharedPreferences(Constants.APP_PREFS, Context.MODE_PRIVATE)
        val city = sharedPrefs.getString("city", "")
        val lat = sharedPrefs.getInt("latitude",0)
        val long = sharedPrefs.getInt("longitude", 0)
        Log.d("lat", "$lat")
        Log.d("long", "$long")
        binding.tvLocation.text = city

        binding.cardLocation.setOnClickListener {
            loadAirData(lat, long)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.home_menu, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.logout_menu -> {
                logout()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    private fun loadAirData(lat: Int, long: Int) {
        showProgressDialog("Loading...")
        retrofitClient.apiService.getAirData(lat, long)
            .enqueue(object : retrofit2.Callback<ApiResponse> {
                override fun onResponse(call: Call<ApiResponse>, response: Response<ApiResponse>) {
                    hideProgressDialog()
                    if (response.isSuccessful) {
                        val apiResponse = response.body()!!
                        Log.d("apiResponse", apiResponse.toString())
                        if (apiResponse.status == "Succes") {

                            val rangeValue = apiResponse.data.airpolution.pm25
                            binding.tvRangeValue.text = rangeValue.toString()
                            Log.d("rangeValue", "${apiResponse.data.airpolution.pm25}")
                            when (rangeValue) {
                                in 0..50 -> binding.tvCategory.text = buildString { append(getString(R.string.baik)) }
                                in 51..100 -> binding.tvCategory.text = buildString { append(getString(R.string.cuput_baik)) }
                                in 101..150 -> binding.tvCategory.text = buildString { append(getString(R.string.tidak_baik)) }
                                in 151..1000 -> binding.tvCategory.text = buildString { append(getString(R.string.berbahaya)) }
                            }

                            binding.tvSuhuValue.text = buildString {
                                append(apiResponse.data.airpolution.t)
                                append("°")
                            }
                            Log.d("suhuValue", "${apiResponse.data.airpolution.t}")

                            val predictedValue = apiResponse.data.predicted[0]
                            Log.d("predictedValue", "${apiResponse.data.predicted[0]}")
                            val roundedPredictedValue = String.format("%.0f", predictedValue)
                            binding.tvPredictedValue.text = roundedPredictedValue

                            binding.tvPredictedType.text = apiResponse.data.predicted[1].toString()
                            Log.d("predictedType", "${apiResponse.data.predicted[1]}")

                            binding.tvKelembabanValue.text = apiResponse.data.airpolution.dew.toString()
                            Log.d("kelembabanValue", "${apiResponse.data.airpolution.dew}")
                            val tekananValue = apiResponse.data.airpolution.p.toDouble() / 9.27
                            val roundedTekananValue = (tekananValue + 0.5).toInt().toString()
                            binding.tvTekananValue.text = buildString {
                                append(roundedTekananValue)
                                append(" mb")
                            }

                            binding.tvKeceapatanValue.text = apiResponse.data.airpolution.w.toString()
                            Log.d("keceapatanValue", "${apiResponse.data.airpolution.w}")
                        } else {
                            Toast.makeText(requireContext(), getString(R.string.something_went_wrong), Toast.LENGTH_LONG).show()
                            Log.d("statusError", "error fetching api data")
                        }
                    }
                }

                override fun onFailure(call: Call<ApiResponse>, t: Throwable) {
                    hideProgressDialog()
                    Log.d("responseFailure", t.message.toString())
                    Toast.makeText(requireContext(), t.message.toString(), Toast.LENGTH_LONG).show()
                }

            })
    }

    private fun logout() {
        //menghapus informasi pengguna disimpan dari SharedPreferences
        clearSession()

        // redirect ke login screen
        startActivity(Intent(requireContext(), LoginActivity::class.java))
        requireActivity().finish()
    }

    private fun clearSession() {
        val sharedPreferences = requireContext().getSharedPreferences(Constants.APP_PREFS, Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.remove("email")
        editor.remove("token")
        editor.apply()
    }

    private fun showProgressDialog(text: String) {
        myProgressDialog = Dialog(requireActivity())
        myProgressDialog.setContentView(R.layout.progress_dialog)
        myProgressDialog.findViewById<TextView>(R.id.tv_progress_text).text = text
        myProgressDialog.setCancelable(false)
        myProgressDialog.setCanceledOnTouchOutside(false)
        myProgressDialog.show()
    }

    private fun hideProgressDialog() {
        myProgressDialog.dismiss()
    }

}