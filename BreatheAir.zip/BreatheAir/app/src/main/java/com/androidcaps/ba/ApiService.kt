package com.androidcaps.ba

import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query

interface ApiService {

    @GET("api/data/")
    fun getAirData(
        @Query("lat") lat: Int,
        @Query("long") lon: Int
    ): Call<ApiResponse>

    @POST("/login")
    fun loginUser(@Body credentials: LoginCredentials): Call<UserResponse>

    @POST("/register")
    fun registerUser(@Body credentials: RegisterCredentials): Call<UserResponse>
}